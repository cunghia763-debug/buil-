import SwiftUI
import UIKit
import AVFoundation

// MARK: - FluxCoreAudioPlayer (stream URL, loops forever, survives background)
final class FluxCoreAudioPlayer: ObservableObject {
    static let shared = FluxCoreAudioPlayer()
    private static let enabledStorageKey = "audio.background.enabled"

    static let stateChangedNotification = Notification.Name("FluxCoreAudioPlayerStateChanged")

    private var player: AVPlayer?
    private var loopObserver: Any?

    @Published private(set) var isPlaying: Bool = false

    private let musicURL = URL(string: "https://www.image2url.com/r2/default/audio/1787540835956-e0b3ebb8-d327-4e8e-8b4b-0f19c86a60d3.mp3")!

    private var resolvedMusicURL: URL {
        AssetPreloadService.cachedURL(key: "audio.background") ?? musicURL
    }

    private init() {
        isPlaying = false
    }

    var shouldPlayOnLaunch: Bool {
        UserDefaults.standard.object(forKey: Self.enabledStorageKey) as? Bool ?? true
    }

    deinit {
        if let loopObserver {
            NotificationCenter.default.removeObserver(loopObserver)
        }
    }

    func play() {
        guard !isPlaying else { return }

        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
        try? session.setActive(true)

        if player == nil {
            player = AVPlayer(url: resolvedMusicURL)
            player?.volume = 0.72
        }
        player?.seek(to: .zero)
        player?.play()

        loopObserver = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime,
            object: player?.currentItem,
            queue: .main
        ) { [weak self] _ in
            self?.player?.seek(to: .zero)
            self?.player?.play()
        }

        isPlaying = true
        UserDefaults.standard.set(true, forKey: Self.enabledStorageKey)
        NotificationCenter.default.post(name: FluxCoreAudioPlayer.stateChangedNotification, object: nil)
    }

    func stop() {
        guard isPlaying else { return }
        player?.pause()
        if let obs = loopObserver {
            NotificationCenter.default.removeObserver(obs)
            loopObserver = nil
        }
        isPlaying = false
        UserDefaults.standard.set(false, forKey: Self.enabledStorageKey)
        NotificationCenter.default.post(name: FluxCoreAudioPlayer.stateChangedNotification, object: nil)
    }
}

typealias ZHModzAudioPlayer = FluxCoreAudioPlayer

@main
struct ThreeOneOSFiveApp: App {
    @StateObject private var appState = AppState()
    @StateObject private var patchDraftCoordinator = PatchDraftCoordinator()
    @StateObject private var fileOperationCoordinator = FileOperationCoordinator()
    @StateObject private var repositoryStore = PackageRepositoryStore()
    @StateObject private var repositoryPatchStore = PatchProjectStore()
    @StateObject private var startupLoader = StartupResourceLoader()
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.vietnamese.rawValue
    @State private var showOnboarding = false
    @State private var showAttribution = false
    @State private var updateOffer: AppUpdateChecker.Offer?
    @Environment(\.scenePhase) private var scenePhase

    init() {
        setupLogCapture()
        log("app: FLUXCORE launching — iOS \(AppInfo.osVersion) (\(AppInfo.osBuild)) \(AppInfo.machineName)")
        if FluxCoreAudioPlayer.shared.shouldPlayOnLaunch {
            FluxCoreAudioPlayer.shared.play()
        }
    }

    private var language: AppLanguage {
        AppLanguage(rawValue: languageCode) ?? .vietnamese
    }

    private func checkForUpdate() {
        Task {
            guard let offer = await AppUpdateChecker.check() else { return }
            await MainActor.run { updateOffer = offer }
        }
    }

    var body: some Scene {
        WindowGroup {
            ZStack {
                ContentView()
                    .environmentObject(appState)
                    .environmentObject(patchDraftCoordinator)
                    .environmentObject(fileOperationCoordinator)
                    .environmentObject(repositoryStore)
                    .environmentObject(repositoryPatchStore)
                    .environment(\.appLanguage, language)
                    .environment(\.locale, language.locale)
            }
            .displayIdentityAttribution(isPresented: $showAttribution, enabled: !showOnboarding)
            .sheet(isPresented: $showAttribution) {
                DisplayAttributionSheet()
            }
            .alert(item: $updateOffer) { offer in
                Alert(
                    title: Text(language.text("update.title")),
                    message: Text(language.text("update.message", offer.version)),
                    primaryButton: .default(Text(language.text("update.agree"))) {
                        UIApplication.shared.open(offer.url)
                    },
                    secondaryButton: .cancel(Text(language.text("update.dismiss"))) {
                        AppUpdateChecker.dismiss(version: offer.version)
                    }
                )
            }
            .onAppear {
                appState.detectSupport()
                checkForUpdate()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                    FloatingWindowManager.shared.show()
                }
            }
            .onChange(of: scenePhase) { phase in
                guard phase == .active, !showOnboarding else { return }
                appState.detectSupport()
            }
            .onOpenURL { url in
                patchDraftCoordinator.presentImport(url)
            }
        }
    }
}

// MARK: - Startup resource gate (kept for background use, no UI)
@MainActor
final class StartupResourceLoader: ObservableObject {
    @Published private(set) var progress: Double = 0
    @Published private(set) var status: String = "Đang khởi tạo APP FLUXCORE..."
    @Published private(set) var detail: String = "Kiểm tra cấu hình ứng dụng"
    @Published private(set) var canSkipFailedPatch = false
    private var started = false

    func skipFailedPatch() {
        guard canSkipFailedPatch else { return }
        canSkipFailedPatch = false
        status = "Đã bỏ qua Patch lỗi"
        detail = "Mở giao diện chính mà không nạp Patch chưa sẵn sàng"
        progress = 1.0
    }
    private let patchStore = PatchProjectStore()
    private let patchFetcher = OnlineFileFetcher()

    func start() async -> Bool {
        guard !started else { return progress >= 1 }
        started = true
        setProgress(0.02, status: "Đang khởi tạo APP FLUXCORE...", detail: "Chuẩn bị bộ nhớ tạm và core engine")
        setProgress(0.12, status: "Đang tải tài nguyên giao diện...", detail: "Icon, hình nền động và video cần thiết")
        await AssetPreloadService.shared.preloadAll()

        let dynamicAssetResult = await DynamicAssetSyncService.shared.sync()
        if !dynamicAssetResult.failed.isEmpty {
            log("startup-assets: supplemental sync failures=\(dynamicAssetResult.failed.joined(separator: ","))")
        }

        setProgress(0.20, status: "Đang kiểm tra cấu hình...", detail: "Đọc trạng thái bảo trì từ máy chủ")
        _ = await AppRuntimeConfig.shared.refresh()

        if AppRuntimeConfig.shared.maintenanceMode {
            setProgress(1.0, status: "Đang ở chế độ bảo trì", detail: "Chỉ mở Trang chủ theo cấu hình máy chủ")
            return true
        }

        setProgress(0.20, status: "Đang kiểm tra Patch...", detail: "Đọc và xác minh toàn bộ Patch cục bộ")

        do {
            let localCount = try PatchProjectLibrary.validateAllLocalPackages()
            log("startup-patch: local integrity verified (\(localCount) package(s))")
        } catch {
            log("startup-patch: local integrity failure – \(error.localizedDescription)")
            canSkipFailedPatch = true
            setProgress(0.20, status: "Patch cục bộ không hợp lệ", detail: "Patch lỗi. Bạn có thể bỏ qua Patch để vào ứng dụng.")
            return false
        }

        var manifestReady = false
        for attempt in 1...3 {
            await patchFetcher.fetchServerFiles()
            if patchFetcher.lastFetchSucceeded {
                manifestReady = true
                break
            }
            setProgress(0.20, status: "Đang kiểm tra Patch (\(attempt)/3)...", detail: "Chưa nhận được manifest, đang thử lại")
            if attempt < 3 {
                try? await Task.sleep(for: .milliseconds(600))
            }
        }

        guard manifestReady else {
            log("startup-patch: manifest verification failed after retries")
            canSkipFailedPatch = true
            setProgress(0.20, status: "Không thể xác minh Patch", detail: "Patch chưa xác minh được. Bạn có thể bỏ qua Patch để vào ứng dụng.")
            return false
        }

        let files = patchFetcher.onlineFiles

        if files.isEmpty {
            setProgress(0.88, status: "Đã xác minh Patch", detail: "Manifest hợp lệ và không có Patch đang hoạt động")
        } else {
            let synchronized = await patchFetcher.preloadAllPatches(
                files: files,
                store: patchStore,
                progress: { [weak self] completed, total, failed, current in
                    guard let self else { return }
                    let fraction = total > 0 ? Double(completed) / Double(total) : 1
                    let mapped = 0.20 + (fraction * 0.68)
                    let suffix = failed > 0 ? " • \(failed) lỗi" : ""
                    self.setProgress(
                        mapped,
                        status: "Đang đồng bộ Patch \(completed)/\(total)",
                        detail: current.isEmpty ? "Đang kiểm tra dữ liệu cục bộ\(suffix)" : "\(current)\(suffix)"
                    )
                },
                itemResult: { file, ok in
                    log("startup-patch: \(ok ? "ready" : "failed") – \(file.title)")
                }
            )

            guard synchronized else {
                log("startup-patch: synchronization failed or was cancelled")
                canSkipFailedPatch = true
                setProgress(0.88, status: "Patch chưa sẵn sàng", detail: "Patch lỗi hoặc chưa đồng bộ được. Bạn có thể bỏ qua Patch để vào ứng dụng.")
                return false
            }

            setProgress(0.88, status: "Đã đồng bộ Patch", detail: "Toàn bộ Patch đang hoạt động đã được xác minh và nhập")
        }

        setProgress(0.90, status: "Đang chuẩn bị nền...", detail: "Cache nền được chọn để mở giao diện nhanh")
        await BackgroundAssetCache.preloadSelectedBackground()

        setProgress(0.96, status: "Đang hoàn tất môi trường...", detail: "Kiểm tra trạng thái cuối cùng của tài nguyên")
        try? await Task.sleep(for: .milliseconds(120))

        setProgress(1.0, status: "Hoàn tất", detail: "Tài nguyên và Patch cần thiết đã sẵn sàng")
        return true
    }

    private func setProgress(_ value: Double, status: String, detail: String) {
        progress = min(max(value, 0), 1)
        self.status = status
        self.detail = detail
    }
}

// MARK: - Local background cache
enum BackgroundAssetCache {
    private static let staticName = "startup-anime-background-static.mov"
    private static let dynamicName = "startup-anime-background-dynamic.mp4"
    private static let lightSkyName = "startup-light-sky-background.mp4"

    private static var cacheDirectory: URL {
        FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("StartupAssets", isDirectory: true)
    }

    static func cachedURL(for key: String) -> URL? {
        if let generic = AssetPreloadService.cachedURL(
            key: {
                switch key {
                case "animeStatic": return "background.static"
                case "animeDynamic": return "background.dynamic"
                case "lightSky": return "background.lightSky"
                default: return key
                }
            }()
        ) {
            return generic
        }
        let name: String
        switch key {
        case "animeStatic": name = staticName
        case "animeDynamic": name = dynamicName
        case "lightSky": name = lightSkyName
        default: return nil
        }
        let url = cacheDirectory.appendingPathComponent(name)
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }

    static func preloadSelectedBackground() async {
        let mode = AppearanceSettings.shared.backgroundMode
        await withTaskGroup(of: Void.self) { group in
            group.addTask {
                await downloadIfNeeded(urlString: AppearanceSettings.BackgroundMode.animeDynamicVideoURL, fileName: dynamicName)
            }
            group.addTask {
                await downloadIfNeeded(urlString: AppearanceSettings.BackgroundMode.lightSkyVideoURL, fileName: lightSkyName)
            }
            if mode == .animeStatic {
                group.addTask {
                    await downloadIfNeeded(urlString: AppearanceSettings.BackgroundMode.animeStaticVideoURL, fileName: staticName)
                }
            }
            for await _ in group {}
        }
    }

    private static func downloadIfNeeded(urlString: String, fileName: String) async {
        guard let url = URL(string: urlString) else { return }
        let destination = cacheDirectory.appendingPathComponent(fileName)
        if FileManager.default.fileExists(atPath: destination.path) { return }
        do {
            try FileManager.default.createDirectory(at: cacheDirectory, withIntermediateDirectories: true)
            let configuration = URLSessionConfiguration.ephemeral
            configuration.timeoutIntervalForRequest = 30
            configuration.timeoutIntervalForResource = 300
            configuration.waitsForConnectivity = true
            let (temporaryURL, response) = try await URLSession(configuration: configuration).download(from: url)
            guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { return }
            try? FileManager.default.removeItem(at: destination)
            try FileManager.default.moveItem(at: temporaryURL, to: destination)
        } catch {
            log("startup-assets: \(error.localizedDescription)")
        }
    }
}

class AppState: ObservableObject {
    @Published var exploitStatus: ExploitStatus = .notStarted
    @Published var unsupportedMessage: String?
    @Published var kernelExploitRunning = false

    private var autoRunAttempted = false

    var kernelExploitApplicable: Bool {
        KernelExploit.isApplicable(
            major: AppInfo.versionTuple.major,
            minor: AppInfo.versionTuple.minor,
            patch: AppInfo.versionTuple.patch,
            build: AppInfo.osBuild
        )
    }

    var isSupported: Bool { unsupportedMessage == nil }

    func detectSupport() {
        let v = AppInfo.versionTuple
        let supported = ExploitSupportPolicy.isSupported(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
#if targetEnvironment(simulator)
        if ProcessInfo.processInfo.arguments.contains("--simulate-access") {
            exploitStatus = .success(method: "Simulator preview")
        }
#endif

        unsupportedMessage = supported ? nil : "iOS \(AppInfo.osVersion) (\(AppInfo.osBuild))"
        if let unsupportedMessage {
            exploitStatus = .unsupported(unsupportedMessage)
            return
        }

        let applicable = KernelExploit.isApplicable(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
        guard applicable else { return }

        refreshKernelExploitStatus()
        maybeAutoRunKernelExploit()
    }

    private func maybeAutoRunKernelExploit() {
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed,
              !autoRunAttempted else { return }
        autoRunAttempted = true
        log("app: starting kernel exploit automatically")
        runKernelExploitIfNeeded()
    }

    private func refreshKernelExploitStatus() {
        guard !kernelExploitRunning else { return }
        if KernelExploit.requiresSandboxEscape {
            if KernelExploit.hasSandboxAccess() {
                if !exploitStatus.isSuccess {
                    exploitStatus = .success(method: "kexploit")
                    log("app: existing sandbox access is still active; skipping kernel exploit")
                }
            } else if exploitStatus.isSuccess {
                exploitStatus = .notStarted
                log("app: sandbox access is no longer active")
            }
        }
    }

    func runKernelExploitIfNeeded() {
        refreshKernelExploitStatus()
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed else { return }
        kernelExploitRunning = true
        exploitStatus = .notStarted
        log("app: running kernel exploit on background...")
        DispatchQueue.global(qos: .userInitiated).async {
            let ok = KernelExploit.run()
            DispatchQueue.main.async {
                self.kernelExploitRunning = false
                if ok {
                    self.exploitStatus = .success(method: "kexploit")
                    if KernelExploit.requiresSandboxEscape {
                        log("app: kernel exploit success — sandbox access verified")
                    } else {
                        log("app: kernel exploit success — kernel access active")
                    }
                } else {
                    self.exploitStatus = .failed(method: "kexploit", code: -1)
                    log("app: kernel exploit failed — relaunch the app before retrying")
                }
            }
        }
    }
}


// MARK: - Remote App Runtime Configuration
struct MaintenanceButton: Codable, Identifiable, Equatable {
    let id: String
    let label: String
    let url: String
}

@MainActor
final class AppRuntimeConfig: ObservableObject {
    static let shared = AppRuntimeConfig()

    @Published private(set) var maintenanceMode = false
    @Published private(set) var maintenanceNotice = "Hệ thống đang bảo trì, vui lòng quay lại sau."
    @Published private(set) var maintenanceInterval: TimeInterval = 10
    @Published private(set) var maintenanceButtons: [MaintenanceButton] = []

    private var refreshTask: URLSessionDataTask?

    private init() {}

    func refresh() async -> Bool {
        refreshTask?.cancel()
        guard let url = URL(string: Self.endpoint) else { return false }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 15
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue("application/json", forHTTPHeaderField: "Accept")

        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse,
                  (200..<300).contains(http.statusCode) else {
                return false
            }

            let envelope = try JSONDecoder().decode(RuntimeEnvelope.self, from: data)
            let value = envelope.value

            let validButtons = value.maintenanceButtons.filter { button in
                guard let components = URLComponents(string: button.url),
                      let scheme = components.scheme?.lowercased(),
                      ["http", "https"].contains(scheme),
                      !button.label.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
                    return false
                }
                return true
            }

            maintenanceMode = value.maintenanceMode
            maintenanceNotice = value.maintenanceNotice
            maintenanceInterval = min(max(TimeInterval(value.maintenanceInterval), 1), 86400)
            maintenanceButtons = validButtons
            return true
        } catch is CancellationError {
            return false
        } catch {
            log("runtime-config: \(error.localizedDescription)")
            return false
        }
    }

    private static let endpoint = "https://appfluxcore.site/api/config.php?key=app_runtime"

    private struct RuntimeEnvelope: Decodable {
        let value: RuntimeValue
    }

    private struct RuntimeValue: Decodable {
        let maintenanceMode: Bool
        let maintenanceNotice: String
        let maintenanceInterval: Int
        let maintenanceButtons: [MaintenanceButton]

        enum CodingKeys: String, CodingKey {
            case maintenanceMode = "maintenance_mode"
            case maintenanceNotice = "maintenance_notice"
            case maintenanceInterval = "maintenance_interval"
            case maintenanceButtons = "maintenance_buttons"
        }
    }
}